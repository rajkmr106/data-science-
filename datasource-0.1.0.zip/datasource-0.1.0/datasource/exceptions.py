class DataSourceError(Exception):
    pass
